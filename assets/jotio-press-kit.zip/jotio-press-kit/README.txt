JOTIO PRESS KIT
================

Thanks for covering Jotio.

This press kit contains everything you need to write about the app:
  • fact-sheet.txt — name, platforms, developer, contact info
  • about-jotio.txt — boilerplate copy, key features, story angles
  • logos/ — app icon, light and dark variants, 128 / 256 / 512 / 1024 px
  • screenshots/ — raw device screenshots (no marketing frames) for iPhone, iPad, Mac, and Apple Watch

USAGE
-----
You're welcome to use these assets in editorial coverage of Jotio (reviews,
articles, videos, podcasts). Please don't crop, recolor, or otherwise modify
the app icon. Screenshots can be cropped, scaled, or arranged freely.

PROMO CODES
-----------
Reviewers can request free App Store promo codes. Just reply to the email
below with the platform you'd like to cover (iOS, Mac, or both).

CONTACT
-------
Heiko Witte
hello@getjotio.app
https://getjotio.app

For the latest version of this kit, visit https://getjotio.app/press
